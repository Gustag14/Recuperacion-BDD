# Bases de Datos – DAM/DAW 25/26

Prácticas de la asignatura **Bases de Datos** del curso 2025-2026.

Repositorio de referencia: https://github.com/jocarsa/basesdedatosdamdaw2526

---

## Estructura

| Carpeta | Contenido |
|---------|-----------|
| `001-Almacenamiento de la información` | Ficheros, tipos de BD, SGBD, legislación, Big Data |
| `002-Bases de datos relacionales` | Modelo relacional, DDL, DCL, índices, vistas... |
| `003-Realización de consultas` | SELECT, JOINs, subconsultas, optimización |
| `004-Tratamiento de datos` | INSERT/UPDATE/DELETE, transacciones, concurrencia |
| `005-Programación de bases de datos` | Procedimientos, funciones, triggers, cursores |
| `006-Interpretación de Diagramas EntidadRelación` | Modelo ER, normalización, paso a tablas |
| `007-Uso de bases de datos no relacionales` | MongoDB, Redis, tipos NoSQL |
| `008-Proyectos` | Login, CRUD, Panel de control, SuperCRUD... |

## Tecnologías
- **MySQL 8.x** — base de datos relacional principal
- **PHP 8.x** — backend de los proyectos web
- **Python 3.x** — scripts de automatización
- **MongoDB** — ejercicios NoSQL documentales
- **Redis** — ejercicios NoSQL clave-valor
